# Client Book

Multi-user client tracker for massage therapists, with a free tier (limited
clients) and a paid tier (unlimited) via Stripe. Reminder emails send
automatically every day for anyone with an appointment that day.

## What's inside

- Next.js app, one account per therapist (Supabase Auth), each user only
  sees their own clients (enforced by database row-level security, not
  just the UI)
- Postgres database via Supabase
- Stripe subscriptions: Checkout for upgrading, a webhook to keep your
  database in sync with Stripe, billing handled entirely by Stripe (no
  card numbers touch your code)
- Resend for actually sending emails
- A daily cron job that automatically emails everyone with an appointment
  that day — no button required

## 1. Supabase (auth + database) — free

1. Go to supabase.com → New project.
2. Once it's ready, go to the SQL Editor → New query, paste in the contents
   of `supabase/schema.sql`, and run it. This creates the tables and the
   security rules that keep each therapist's clients private.
3. Go to Project Settings → API. Copy:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (keep this one secret —
     it bypasses the privacy rules, and is only used by the webhook/cron)
4. Go to Authentication → Providers, and make sure Email is enabled
   (it is by default). Under Authentication → URL Configuration, add your
   deployed URL once you have one (step 5) as a redirect URL.

## 2. Stripe (payments) — free to set up

1. Go to stripe.com → create an account.
2. Go to Product catalog → Add product. Name it (e.g. "Pro plan"), set a
   recurring monthly price. Save it, then copy the Price ID
   (starts with `price_...`) → `STRIPE_PRICE_ID`.
3. Go to Developers → API keys → copy the Secret key → `STRIPE_SECRET_KEY`.
   Use the test key while you're setting things up; switch to the live key
   when you're ready to take real payments.
4. You'll set up the webhook (`STRIPE_WEBHOOK_SECRET`) in step 5, after you
   have a deployed URL to point it at.

## 3. Resend (sending real emails) — free tier available

1. Go to resend.com → create an account.
2. Verify a sending domain (or use their test domain while developing).
3. Create an API key → `RESEND_API_KEY`.
4. Set `RESEND_FROM_EMAIL` to an address on your verified domain.

## 4. Push this code to GitHub

```
cd client-book
git init
git add .
git commit -m "Client book app"
```
Create a new repo on github.com, then follow its instructions to push.

## 5. Deploy on Vercel — free

1. Go to vercel.com → New Project → import your GitHub repo.
2. Before deploying, add all the environment variables from `.env.example`
   (Vercel → Project → Settings → Environment Variables). Set
   `NEXT_PUBLIC_APP_URL` to the `https://your-app.vercel.app` URL Vercel
   gives you (you can find/update this after the first deploy).
3. Set `FREE_TIER_CLIENT_LIMIT` to whatever number you want the free plan
   capped at (e.g. `5`).
4. Set `CRON_SECRET` to any random string you make up — it just stops
   strangers from calling your reminder endpoint directly.
5. Deploy.
6. Back in Stripe → Developers → Webhooks → Add endpoint. URL:
   `https://your-app.vercel.app/api/webhook`. Select events:
   `checkout.session.completed`, `customer.subscription.updated`,
   `customer.subscription.deleted`. Copy the signing secret →
   set `STRIPE_WEBHOOK_SECRET` in Vercel and redeploy.
7. Vercel will automatically pick up `vercel.json` and run the daily
   reminder cron for you — nothing else to configure.

## Trying it locally first (optional)

```
npm install
cp .env.example .env.local   # fill in the values from steps 1-3
npm run dev
```

## Changing the price or free-tier limit later

- Free tier limit: change `FREE_TIER_CLIENT_LIMIT` in Vercel's environment
  variables and redeploy.
- Price: change it in the Stripe dashboard, and update `STRIPE_PRICE_ID` if
  you create a new price rather than editing the existing one.
